public class Baby
{
    public static void main(String[] args)
    {
      Picture babyTaran = new Picture("taran_avatar.jpg");
      babyTaran.draw();
    }
}