
/**
 * Practice using ArrayList data type (DRAFT).
 * 
 * @author (Scot Matson) 
 * @version (2014/10/23)
 */

import java.util.ArrayList;

public class ArrayListFun
{
    public static void main(String[] args)
    {
        ArrayList<String> garden = new ArrayList<String>();
        garden.add("pansy");
        garden.add("daisy");
        garden.add("violet");
        System.out.println(garden.toString());
    }
}

