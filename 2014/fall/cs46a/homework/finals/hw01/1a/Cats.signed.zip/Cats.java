
public class Cats
{
    public static void main(String[] args)
    {
      System.out.println("*----*");
        System.out.println("*cat");
        System.out.println("*gato");
        System.out.println("*\u306d\u3053");
        System.out.println("*----*");
    }
}
