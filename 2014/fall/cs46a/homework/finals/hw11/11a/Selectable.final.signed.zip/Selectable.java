/**
 * Created by scot on 11/27/14.
 * Assignment: 11a {FINAL}
 * Course: cs46a-01
 */
public interface Selectable {

    public boolean select();
}
