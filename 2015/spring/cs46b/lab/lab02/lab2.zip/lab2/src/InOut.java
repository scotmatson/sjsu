public interface InOut
{
   String nextLine(String prompt);
   void message(String text);
}
