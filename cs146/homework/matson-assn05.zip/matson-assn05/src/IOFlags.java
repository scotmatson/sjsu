package assignment05;

/**
 Created by scot on 7/19/15.
 */
public enum IOFlags
{
   CONSOLE,
   TEXTFILE
}
