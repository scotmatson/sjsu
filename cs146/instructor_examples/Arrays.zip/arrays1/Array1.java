package arrays1;

// Sort a simple int[] array of primitive integers.

public class Array1 
{
    private static void print(int elements[])
    {
        for (int elmt : elements) {
            System.out.print(" " + elmt);
        }
        System.out.println();
    }

    private static void sort(int elements[])
    {
        for (int i = 0; i < elements.length-1; i++) {
            for (int j = i+1; j < elements.length; j++) {
                if (elements[j] < elements[i]) {
                    int temp = elements[i];
                    elements[i] = elements[j];
                    elements[j] = temp;
                }
            }
        }
    }

    public static void main(String[] args) 
    {
        int numbers[] = new int[] {5, 1, 9, 4, 5, 0, 7, 6};

        System.out.print("Before sorting:"); print(numbers);
        sort(numbers);
        System.out.print(" After sorting:"); print(numbers);
    }
}
