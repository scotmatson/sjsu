package arrays1;

import java.util.ArrayList;

// ArrayList<Integer> of Integer objects.

public class Array3 
{
    private static void print(ArrayList<Integer> elements)
    {
        for (Integer elmt : elements) {
            System.out.print(" " + elmt.intValue());
        }
        System.out.println();
    }

    private static void sort(ArrayList<Integer> elements)
    {
        for (int i = 0; i < elements.size()-1; i++) {
            for (int j = i+1; j < elements.size(); j++) {
                if (elements.get(j).intValue() < elements.get(i).intValue()) {
                    Integer temp = elements.get(i);
                    elements.set(i, elements.get(j));
                    elements.set(j, temp);
                }
            }
        }
    }

    public static void main(String[] args) 
    {
        ArrayList<Integer> numbers = new ArrayList<>();
        numbers.add(new Integer(5));
        numbers.add(new Integer(1));
        numbers.add(new Integer(9));
        numbers.add(new Integer(4));
        numbers.add(new Integer(5));
        numbers.add(new Integer(0));
        numbers.add(new Integer(7));
        numbers.add(new Integer(6));

        System.out.print("Before sorting:"); print(numbers);
        sort(numbers);
        System.out.print(" After sorting:"); print(numbers);
    }
}
