package arrays1;

import java.util.ArrayList;

// Auto boxing and unboxing.

public class Array4 
{
    private static void print(ArrayList<Integer> elements)
    {
        for (Integer elmt : elements) {
            System.out.print(" " + elmt);
        }
        System.out.println();
    }

    private static void sort(ArrayList<Integer> elements)
    {
        for (int i = 0; i < elements.size()-1; i++) {
            for (int j = i+1; j < elements.size(); j++) {
                if (elements.get(j) < elements.get(i)) {
                    Integer temp = elements.get(i);
                    elements.set(i, elements.get(j));
                    elements.set(j, temp);
                }
            }
        }
    }

    public static void main(String[] args) 
    {
        ArrayList<Integer> numbers = new ArrayList<>();
        numbers.add(5);
        numbers.add(1);
        numbers.add(9);
        numbers.add(4);
        numbers.add(5);
        numbers.add(0);
        numbers.add(7);
        numbers.add(6);

        System.out.print("Before sorting:"); print(numbers);
        sort(numbers);
        System.out.print(" After sorting:"); print(numbers);
    }
}
