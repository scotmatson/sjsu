package arrays2;

// Raw Comparable interface.

public abstract class SimpleShape implements Comparable
{
    public abstract float area();

    public int compareTo(Object other)
    {
        return (int) (this.area() - ((SimpleShape) other).area());
    }
}