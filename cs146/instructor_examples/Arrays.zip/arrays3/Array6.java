package arrays3;

import java.util.ArrayList;

// ArrayList<SimpleShape> of SimpleShape objects.
// SimpleShape implements the Comparable<SimpleShape> interface.

public class Array6 
{
	private static void print(ArrayList<SimpleShape> elements)
	{
		for (SimpleShape elmt : elements) {
			System.out.print(" " + elmt);
		}
		System.out.println();
	}
	
	private static void sort(ArrayList<SimpleShape> elements)
	{
		for (int i = 0; i < elements.size()-1; i++) {
			for (int j = i+1; j < elements.size(); j++) {
				if (elements.get(j).compareTo(elements.get(i)) < 0) {
					SimpleShape temp = elements.get(i);
					elements.set(i, elements.get(j));
					elements.set(j, temp);
				}
			}
		}
	}
	
	public static void main(String[] args) 
	{
		ArrayList<SimpleShape> shapes = new ArrayList<>();
		shapes.add(new Square(5));
		shapes.add(new Rectangle(3, 4));
		shapes.add(new Circle(2));
		
		System.out.print("Before sorting:"); print(shapes);
		sort(shapes);
		System.out.print(" After sorting:"); print(shapes);
	}
}
