package arrays3;

public abstract class SimpleShape implements Comparable<SimpleShape>
{
    public abstract float area();

    public int compareTo(SimpleShape other)
    {
        return (int) (this.area() - other.area());
    }
}