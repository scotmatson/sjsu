package arrays4;

// In method max(), the compiler can't tell that
// the call to method compareTo() is valid.

public class Array10 
{
    private static <MyType> MyType max(MyType elements[]) 
    {
        int maxIndex = 0;

        for (int i = 1; i < elements.length; i++) {
            if (elements[i].compareTo(elements[maxIndex]) > 0) {
                maxIndex = i;
            }
        }

        return elements[maxIndex];
    }

    public static void main(String[] args) 
    {
        SimpleShape shapes[] = new SimpleShape[] {
                new Square(5),
                new Rectangle(3, 4),
                new Circle(2)
        };

        System.out.println("Largest shape: " + max(shapes));
    }
}