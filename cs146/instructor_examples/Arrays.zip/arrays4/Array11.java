package arrays4;

// A correct syntax for the header of method max().

public class Array11
{
    private static <MyType extends SimpleShape> 
        MyType max(MyType elements[]) 
    {
        int maxIndex = 0;

        for (int i = 1; i < elements.length; i++) {
            if (elements[i].compareTo(elements[maxIndex]) > 0) {
                maxIndex = i;
            }
        }

        return elements[maxIndex];
    }

    public static void main(String[] args) 
    {
        SimpleShape shapes[] = new SimpleShape[] {
                new Square(5),
                new Rectangle(3, 4),
                new Circle(3)
        };

        System.out.println("Largest shape: " + max(shapes));
    }
}