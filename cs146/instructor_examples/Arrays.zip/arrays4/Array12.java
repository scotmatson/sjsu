package arrays4;

// This also works for the header of method max(),
// despite what the textbook says. Don't try to
// call method area() on each element, though. (Why not?)

public class Array12 
{
    private static <MyType extends Comparable<MyType>> 
        MyType max(MyType elements[]) 
    {
        int maxIndex = 0;

        for (int i = 1; i < elements.length; i++) {
            if (elements[i].compareTo(elements[maxIndex]) > 0) {
                maxIndex = i;
            }
        }

        return elements[maxIndex];
    }

    public static void main(String[] args) 
    {
        SimpleShape shapes[] = new SimpleShape[] {
                new Square(5),
                new Rectangle(3, 4),
                new Circle(3)
        };

        System.out.println("Largest shape: " + max(shapes));
    }
}