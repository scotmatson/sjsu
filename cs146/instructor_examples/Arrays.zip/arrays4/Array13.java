package arrays4;

// Awful syntax for the header of method max(), but it works!

public class Array13 
{
    private static <MyType extends Comparable<? super MyType>> 
        MyType max(MyType elements[]) 
    {
        int maxIndex = 0;

        for (int i = 1; i < elements.length; i++) {
            if (elements[i].compareTo(elements[maxIndex]) > 0) {
                maxIndex = i;
            }
        }

        return elements[maxIndex];
    }

    public static void main(String[] args) 
    {
        SimpleShape shapes[] = new SimpleShape[] {
                new Square(5),
                new Rectangle(3, 4),
                new Circle(3)
        };

        System.out.println("Maximum area: " + max(shapes));
    }
}