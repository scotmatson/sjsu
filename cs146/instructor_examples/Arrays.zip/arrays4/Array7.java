package arrays4;

// Arrays are covariant!
// Because Square is a subclass of SimpleShape,
// Square[] is type compatible with SimpleShape[].

public class Array7 
{
    private static float totalArea(SimpleShape elements[])
    {
        float total = 0;

        for (SimpleShape elmt : elements) {
            total += elmt.area();
        }

        return total;
    }

    public static void main(String[] args) 
    {
        SimpleShape shapes[] = new SimpleShape[] {
                new Square(5),
                new Rectangle(3, 4),
                new Circle(2)
        };

        System.out.println("Total area: " + totalArea(shapes));

        Square squares[] = new Square[] {
                new Square(5),
                new Square(3),
                new Square(2)
        };

        System.out.println("Total area: " + totalArea(squares));
    }
}
