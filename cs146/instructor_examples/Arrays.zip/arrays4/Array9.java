package arrays4;

import java.util.ArrayList;

// Fix the noncovariance of ArrayLists in method totalArea().

public class Array9 
{
    private static float totalArea(ArrayList<? extends SimpleShape> elements) 
    {
        float total = 0;

        for (SimpleShape elmt : elements) {
            total += elmt.area();
        }

        return total;
    }

    public static void main(String[] args) 
    {
        ArrayList<Square> squares = new ArrayList<>();
        squares.add(new Square(5));
        squares.add(new Square(3));
        squares.add(new Square(2));

        System.out.println("Total area: " + totalArea(squares));
    }
}