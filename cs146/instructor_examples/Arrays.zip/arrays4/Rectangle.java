package arrays4;

public class Rectangle extends SimpleShape 
{
	private float width, height;
	
	public Rectangle(int width, int height)
	{
		this.width = width;
		this.height = height;
	}
	
	public float area()
	{
		return width*height;
	}
}
