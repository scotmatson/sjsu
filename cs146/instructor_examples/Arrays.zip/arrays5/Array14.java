package arrays5;

import java.util.Comparator;

// Use a function object.

public class Array14 
{
    private static <MyType> 
        MyType max(MyType elements[], Comparator<? super MyType> comp) 
    {
        int maxIndex = 0;

        for (int i = 1; i < elements.length; i++) {
            if (comp.compare(elements[i], elements[maxIndex]) > 0) {
                maxIndex = i;
            }
        }

        return elements[maxIndex];
    }
    
    private static class HeightComparator implements Comparator<Rectangle>
    {
        public int compare(Rectangle rect1, Rectangle rect2)
        {
            return (int) (rect1.getHeight() - rect2.getHeight());
        }
    }

    public static void main(String[] args) 
    {
        Rectangle rectangles[] = new Rectangle[] {
            new Rectangle(2, 5),
            new Rectangle(3, 4),
            new Rectangle(1, 6)
        };
    
        System.out.println(
            "Maximum height: " + 
            max(rectangles, new HeightComparator()).getHeight());
    }
}