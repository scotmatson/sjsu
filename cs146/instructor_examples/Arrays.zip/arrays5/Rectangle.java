package arrays5;

public class Rectangle extends SimpleShape 
{
	private float width, height;
	
	public Rectangle(int width, int height)
	{
		this.width = width;
		this.height = height;
	}
	
	public float getHeight() { return height; }
	
	public float area()
	{
		return width*height;
	}
}
