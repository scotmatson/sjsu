public class DaysLeftPrinter
{
   public static void main(String[] args)
   {
       //put your code here
       Day today = new Day();
       
       System.out.println(today.toString()); //do not change this line
       //DO NOT put code here
   }
}