public class StringFun {
  public static void main(String[] args) {
    String word = "create"; 
       // do not change the line above here
       // your code goes below here
    int strDblLength = 0;
    
    strDblLength = word.length() * 2;

    System.out.println(strDblLength);
  }
}