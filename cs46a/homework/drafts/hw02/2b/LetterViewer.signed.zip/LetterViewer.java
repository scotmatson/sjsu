public class LetterViewer
{
   public static void main(String[] args)
   {
      Ellipse ellipse = new Ellipse(40, 10, 50, 50);
      ellipse.draw();    
   }
}