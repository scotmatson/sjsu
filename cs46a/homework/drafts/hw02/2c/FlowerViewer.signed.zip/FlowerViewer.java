public class FlowerViewer
{
    public static void main(String[] args)
    {
     Ellipse flwrBud = new Ellipse(50, 40, 30, 30);
     Color yellow = new Color(255, 255, 0);
   
     flwrBud.setColor(yellow);
     flwrBud.fill();
    }
}
