public class RobotDemo
{
    public static void main(String[] args)
    {
        Robot carol = new Robot();

        carol.moveForward();
        carol.moveForward();
        carol.moveForward();
        carol.say("Hello, Coder!");
    }
}
