/**
 * Created by scot on 4/10/15.
 *
 * File used to test the functionality of the zipup bash script
 *  for sjsu cs46b lab 10
 *
 */
public class Tester {

    public static void main(String[] args) {


        // Arbitrary text output to text shell script
        System.out.println("Testing bash shell script.");
    }



}
