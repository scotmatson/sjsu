#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct ListNode {
  unsigned int data;
  char name[16];
  char grade;
  struct ListNode *next;
};

void insertList(struct ListNode *lptr, unsigned int idata, char *iname, char igrade) {
  
  struct ListNode *next_node;
  struct ListNode *new_node  = (struct ListNode*) malloc(sizeof(struct ListNode)); 
   
  new_node->data = idata;
  strcpy(new_node->name, iname);
  new_node->grade = igrade;
  
  if (lptr->next == NULL) {
    new_node->next = lptr->next;
    lptr->next = new_node;
  }
  else {
    new_node->next = lptr->next;
    lptr->next = new_node;
  }

  next_node = lptr->next;
  if (new_node->data > next_node->data) {
 //   new_node->next = next_node->next;
 //   next_node->next = new_node;
  }

}

void printList(FILE *fpo, struct ListNode *lptr) {
  lptr = lptr->next;
  while (lptr->next != NULL) {
    fprintf(fpo, "%09u \t%s \t%c\n", lptr->data, lptr->name, lptr->grade);
    lptr = lptr->next;
  }
}

void freeList (struct ListNode *lptr) {
  // will free memory locations here
  struct ListNode *temp_node;
  while (lptr->next != NULL) {
    temp_node = lptr; 
    lptr = lptr->next;
    free(temp_node);
  }
}



